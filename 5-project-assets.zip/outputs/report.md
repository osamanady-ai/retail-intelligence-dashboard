# Online Retail findings

- Raw lines: 541,909; analyzed lines: 534,129.
- Gross sales: GBP 10,642,110.80; credits: GBP 893,979.73.
- Net sales: GBP 9,748,131.07 across 19,960 sales invoices.
- Gross average order value: GBP 533.17.
- Top net-sales country: United Kingdom.

These are transaction values, not profit: there is no cost-of-goods data.
Credits in this date window can relate to earlier purchases, so credits divided by sales
is a value ratio, not an order-return probability. Missing CustomerID does not mean zero sales;
those lines remain in revenue totals and are excluded only from customer-specific analysis.
Exact duplicate lines are removed under a stated ingestion-cleaning assumption, although
some identical lines could be legitimate repeated purchases. No invoice-level deduplication.
The final month ends on 9 December 2011, so it is not comparable with a full month.
Data are historical UK transactions in GBP, not current Egyptian market data.

![Transaction overview](sales_dashboard.png)
